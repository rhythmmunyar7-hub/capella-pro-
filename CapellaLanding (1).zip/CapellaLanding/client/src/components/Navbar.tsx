import { useEffect, useState } from "react";
import { nav } from "@/content/copy";
import logoUrl from "@assets/Screenshot 2025-10-16 235531_1760639166775.png";

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-background/80 backdrop-blur-md shadow-sm" : "bg-transparent"
      }`}
      data-testid="navbar"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <img
              src={logoUrl}
              alt="Capella Pro"
              className="h-8 w-8"
              data-testid="img-logo"
            />
            <span className="ml-2 text-lg font-semibold text-foreground" data-testid="text-brand-name">
              Capella Pro
            </span>
          </div>

          <div className="flex items-center gap-8">
            <button
              onClick={() => scrollToSection("how-it-works")}
              className="text-foreground hover-elevate px-3 py-2 rounded-md text-sm font-medium transition-colors"
              data-testid="link-how-it-works"
            >
              {nav.howItWorks}
            </button>
            <button
              onClick={() => scrollToSection("about")}
              className="text-foreground hover-elevate px-3 py-2 rounded-md text-sm font-medium transition-colors"
              data-testid="link-about"
            >
              {nav.about}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
