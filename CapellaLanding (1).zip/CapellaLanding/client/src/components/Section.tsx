interface SectionProps {
  id?: string;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  className?: string;
}

export function Section({ id, title, subtitle, children, className = "" }: SectionProps) {
  return (
    <section
      id={id}
      className={`py-20 px-4 sm:px-6 lg:px-8 ${className}`}
      data-testid={id ? `section-${id}` : "section"}
    >
      <div className="max-w-7xl mx-auto">
        {(title || subtitle) && (
          <div className="text-center mb-16 space-y-4">
            {title && (
              <h2
                className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground"
                data-testid="text-section-title"
              >
                {title}
              </h2>
            )}
            {subtitle && (
              <p
                className="text-lg text-muted-foreground max-w-3xl mx-auto"
                data-testid="text-section-subtitle"
              >
                {subtitle}
              </p>
            )}
          </div>
        )}
        {children}
      </div>
    </section>
  );
}
