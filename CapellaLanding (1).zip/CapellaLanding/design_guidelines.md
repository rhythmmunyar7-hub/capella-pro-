# Capella Pro Landing Page - Design Guidelines

## Design Approach
**Minimalist Conversion-Focused Design** - Clean, distraction-free interface optimized for waitlist signups with clear information hierarchy.

## Color Palette

### Base Colors
- **Background**: #F5F5F5 (Tailwind bg-gray-100)
- **Text**: Black (#000000)
- **Accent**: Minimal use, only for CTAs and interactive elements

### Interaction States
- Focus states: Clear, accessible outlines
- Hover states: Subtle transitions for links and buttons

## Typography

### Font Family
- **Primary**: Inter (via next/font)
- Clean, modern sans-serif for excellent readability

### Hierarchy
- **Hero Headline**: Large, bold, attention-grabbing
- **Subheadline**: Medium weight, supporting text
- **Section Titles**: Bold, clear section headers
- **Body Text**: Regular weight, optimal line-height for readability
- **Helper Text**: Smaller, lighter for secondary information

## Layout System

### Spacing Philosophy
- **Generous Whitespace**: Lots of breathing room between sections
- **Consistent Padding**: Uniform section padding for rhythm
- **Mobile-First**: Stack elements vertically on mobile, expand on desktop

### Grid Structure
- **Navbar**: Flex layout - logo left, navigation links right
- **Hero**: Two-column on desktop (content left, mockup right), stacked on mobile
- **How It Works**: 3-column card grid on desktop, single column on mobile
- **About**: Single column centered content with value cards

## Component Library

### Navbar
- **Position**: Sticky top with translucent background
- **Background**: Slight blur effect on scroll for depth
- **Logo**: Top-left, uses placeholder image at /public/logo.png
- **Navigation**: Text-only links ("How It Works", "About") - smooth scroll behavior
- **No CTA Button**: Clean, minimal navigation

### Hero Section
- **Layout**: Content block with vertical form stacking
- **Elements**: 
  - Headline and subtitle (left-aligned or centered)
  - Email input (full width, proper accessible label)
  - Join Waitlist button BELOW input (full width, stacked)
  - Helper text: "Early adopters get exclusive perks" under button
- **Visual**: Product mockup placeholder on right (card with preview text)
- **Form Behavior**: Client-side validation with toast notification on success

### Section Component
- **Container**: Max-width constraint with centered content
- **Structure**: Title, optional subtitle, then content
- **Background**: Consistent grey (#F5F5F5)

### How It Works Section
- **3-Step Cards**: 
  - Small icons at top of each card
  - Bold step title
  - Descriptive body text
- **Visual Flow**: Left to right progression showing product journey

### About Section
- **Mission Statement**: Centered paragraph with clear messaging
- **Values Display**: 3 value cards with titles and descriptions
  - Simplicity: "Fewer clicks, more flow"
  - Speed: "Lightweight, responsive, distraction-free"
  - Focus: "Tools that keep you in the zone"
- **Built in Public Note**: Transparent development message

### Toast Notification
- **Style**: Simple, unobtrusive success message
- **Trigger**: Waitlist signup confirmation
- **Message**: "Thanks for joining the waitlist!"

## Interactions & Animations

### Animation Principles
- **Minimal**: Only when necessary for user feedback
- **Subtle**: Gentle transitions, no distracting motion
- **Purpose-Driven**: Enhance UX, not distract from conversion

### Scroll Behavior
- **Smooth Scrolling**: For anchor link navigation
- **Navbar Transform**: Subtle background change on scroll

## Accessibility

### Core Requirements
- **Semantic HTML**: Proper heading hierarchy, landmarks
- **Form Labels**: Accessible labels for all inputs
- **Focus States**: Clear keyboard navigation indicators
- **Contrast**: Strong black-on-grey ensures readability
- **Responsive**: Mobile-first ensures all devices work well

## Content Strategy

### Centralized Copy Management
- **Single Source**: All text in /content/copy.ts
- **Easy Updates**: Simple to modify messaging without touching components
- **Consistency**: Ensures unified voice across all sections

### Conversion Focus
- **Clear Value Prop**: Hero immediately communicates benefit
- **Low Friction**: Direct email signup, no unnecessary fields
- **Social Proof**: "Early adopter perks" creates urgency
- **Information Hierarchy**: How It Works → About flow builds understanding

## Images

### Hero Section
- **Product Mockup**: Right side of hero (desktop)
- **Style**: Card-based placeholder with "Capella Pro dashboard preview" text
- **Purpose**: Visual representation of the product interface

### Logo
- **Location**: /public/logo.png (placeholder for client's actual logo)
- **Placement**: Top-left navbar, consistent across all viewports

## Responsive Behavior

### Mobile (< 768px)
- Hero: Stacked layout (content, then mockup)
- Form: Full-width input and button stacked vertically
- How It Works: Single column card stack
- About: Centered single column

### Desktop (≥ 768px)
- Hero: Two-column (content left, mockup right)
- Form: Maintained vertical stack for consistency
- How It Works: 3-column card grid
- About: Centered content with inline value cards

## Meta & SEO
- **Title**: "Capella Pro — All-in-one productivity"
- **Description**: "Replace multiple tools with one fast, focused workspace"