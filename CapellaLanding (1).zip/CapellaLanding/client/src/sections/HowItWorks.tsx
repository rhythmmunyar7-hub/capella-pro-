import { Section } from "@/components/Section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { howItWorks } from "@/content/copy";
import { Layers, Sparkles, TrendingUp } from "lucide-react";

const icons = [Layers, Sparkles, TrendingUp];

export function HowItWorks() {
  return (
    <Section id="how-it-works" title={howItWorks.title}>
      <div className="grid md:grid-cols-3 gap-8">
        {howItWorks.steps.map((step, index) => {
          const Icon = icons[index];
          return (
            <Card
              key={index}
              className="border-border hover-elevate transition-all"
              data-testid={`card-step-${index + 1}`}
            >
              <CardHeader>
                <div className="mb-4">
                  <div className="w-12 h-12 rounded-md bg-primary flex items-center justify-center">
                    <Icon className="w-6 h-6 text-primary-foreground" />
                  </div>
                </div>
                <CardTitle className="text-xl" data-testid={`text-step-title-${index + 1}`}>
                  {step.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground" data-testid={`text-step-body-${index + 1}`}>
                  {step.body}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </Section>
  );
}
