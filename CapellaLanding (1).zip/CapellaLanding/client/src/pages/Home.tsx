import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { HowItWorks } from "@/sections/HowItWorks";
import { About } from "@/sections/About";
import { useEffect } from "react";

export default function Home() {
  useEffect(() => {
    document.title = "Capella Pro — All-in-one productivity";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Replace multiple tools with one fast, focused workspace.");
    } else {
      const meta = document.createElement("meta");
      meta.name = "description";
      meta.content = "Replace multiple tools with one fast, focused workspace.";
      document.head.appendChild(meta);
    }
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <HowItWorks />
      <About />
    </div>
  );
}
