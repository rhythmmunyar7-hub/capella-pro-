import { useState } from "react";
import { hero } from "@/content/copy";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";

export function Hero() {
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!email) {
      toast({
        title: "Email required",
        description: "Please enter your email address",
        variant: "destructive",
      });
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }

    console.log("Waitlist signup:", email);
    
    toast({
      title: "Thanks for joining the waitlist!",
      description: "We'll be in touch soon with exclusive early access.",
    });

    setEmail("");
  };

  return (
    <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8" data-testid="section-hero">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1
                className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight"
                data-testid="text-hero-title"
              >
                {hero.title}
              </h1>
              <p
                className="text-lg sm:text-xl text-muted-foreground"
                data-testid="text-hero-subtitle"
              >
                {hero.subtitle}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="space-y-2">
                <label htmlFor="email" className="sr-only">
                  Email address
                </label>
                <Input
                  id="email"
                  type="email"
                  placeholder={hero.emailPlaceholder}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full text-base"
                  data-testid="input-email"
                />
              </div>
              <Button
                type="submit"
                size="lg"
                className="w-full"
                data-testid="button-join-waitlist"
              >
                {hero.button}
              </Button>
              <p
                className="text-sm text-muted-foreground text-center"
                data-testid="text-early-adopter-note"
              >
                {hero.note}
              </p>
            </form>
          </div>

          <div className="hidden lg:block">
            <Card className="p-8 bg-card border-border" data-testid="card-product-preview">
              <div className="aspect-video flex items-center justify-center bg-muted rounded-md">
                <p className="text-muted-foreground text-center px-4" data-testid="text-preview-placeholder">
                  Capella Pro dashboard preview
                </p>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
