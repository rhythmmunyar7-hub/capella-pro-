# Capella Pro Landing Page

## Overview

Capella Pro is a minimalist, conversion-focused landing page for an all-in-one productivity suite targeting freelancers and solopreneurs. The application is built as a single-page marketing site with a waitlist signup form, featuring a clean design with generous whitespace and a focus on driving email capture conversions.

The project uses a modern React-based stack with Vite for development, Express for serving, and is structured as a monorepo with client and server separation. The landing page includes sections for hero/signup, how it works, and about information, all optimized for mobile-first responsive design.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server, providing fast HMR and optimized production builds
- Wouter for lightweight client-side routing (currently single-page with 404 handling)
- Mobile-first responsive design approach using Tailwind CSS

**Component Structure**
- Shadcn UI component library (New York style) for consistent, accessible UI components
- Radix UI primitives as the foundation for interactive components (dialogs, tooltips, toasts, etc.)
- Custom components organized in `/client/src/components` with reusable Section and layout components
- Content separation pattern: All copy stored in `/client/src/content/copy.ts` for easy updates without touching component logic

**State Management**
- React Query (TanStack Query) for server state management and API communication
- Local component state using React hooks for form inputs and UI interactions
- Toast notifications for user feedback (form submissions, errors)

**Styling System**
- Tailwind CSS with custom configuration for design system tokens
- CSS variables for theme colors (HSL color space for flexibility)
- Custom utility classes for elevation effects (`hover-elevate`, `active-elevate-2`)
- Inter font family loaded via Google Fonts for clean, modern typography

### Backend Architecture

**Server Framework**
- Express.js server for HTTP handling and static file serving
- Development and production modes with conditional Vite middleware integration
- Custom logging middleware for API request tracking

**API Structure**
- RESTful API pattern with `/api` prefix for all application routes
- Route registration system in `/server/routes.ts` for modular endpoint definitions
- Currently minimal API surface (landing page is primarily static)

**Error Handling**
- Centralized error middleware catching and formatting errors with status codes
- Development-specific error overlays via Replit Vite plugins

### Data Storage

**Database Configuration**
- Drizzle ORM configured for PostgreSQL with schema definitions in `/shared/schema.ts`
- Schema currently defines a users table with UUID primary keys and username/password fields
- Database migrations managed via Drizzle Kit in `/migrations` directory

**Storage Abstraction**
- IStorage interface pattern for pluggable storage implementations
- MemStorage in-memory implementation for development/testing
- Designed to swap between in-memory and database-backed storage without changing application code

**Current Schema**
```typescript
users table:
- id: UUID (auto-generated primary key)
- username: text (unique, required)
- password: text (required)
```

### External Dependencies

**UI Component Libraries**
- Radix UI: Comprehensive set of unstyled, accessible component primitives (accordion, dialog, dropdown, select, tabs, toast, tooltip, etc.)
- Lucide React: Icon library for consistent iconography
- Class Variance Authority: Type-safe variant styling for component APIs
- Embla Carousel: Touch-friendly carousel component

**Form Management**
- React Hook Form: Form state and validation
- @hookform/resolvers: Integration with Zod for schema validation
- Zod: Runtime type validation and schema definitions
- drizzle-zod: Auto-generate Zod schemas from Drizzle database schemas

**Database & Backend**
- @neondatabase/serverless: Serverless PostgreSQL driver for Neon database
- Drizzle ORM: Type-safe SQL query builder and migration tool
- connect-pg-simple: PostgreSQL session store for Express sessions

**Development Tools**
- Replit-specific Vite plugins: Runtime error modal, cartographer, dev banner
- TypeScript for static type checking across client and server
- PostCSS with Autoprefixer for CSS processing
- esbuild for server-side bundling in production builds

**Utilities**
- date-fns: Date manipulation and formatting
- clsx + tailwind-merge: Conditional className composition
- cmdk: Command menu component (not currently visible in UI)
- nanoid: Unique ID generation

**Build & Runtime**
- tsx: TypeScript execution for development server
- Node.js as the runtime environment
- Vite for client bundling, Express for server runtime