export const nav = {
  howItWorks: "How It Works",
  about: "About"
};

export const hero = {
  title: "All-in-one productivity for freelancers & solopreneurs",
  subtitle: "Replace multiple tools with one fast, focused workspace.",
  emailPlaceholder: "Enter your email",
  button: "Join Waitlist",
  note: "Early adopters get exclusive perks"
};

export const howItWorks = {
  title: "How It Works",
  steps: [
    {
      title: "Bring everything together",
      body: "Tasks, calendar, clients, finance, and notes in one place."
    },
    {
      title: "Work smarter with AI",
      body: "Prioritize tasks, plan your day, and focus with Pomodoro."
    },
    {
      title: "Track progress effortlessly",
      body: "See earnings, deadlines, and streaks at a glance."
    }
  ]
};

export const about = {
  title: "About Capella Pro",
  body: "Capella Pro is an all-in-one productivity suite for freelancers and solopreneurs. Replace tool overload with one simple, fast workspace—built to help you focus, deliver, and grow.",
  values: [
    {
      title: "Simplicity",
      body: "Fewer clicks, more flow."
    },
    {
      title: "Speed",
      body: "Lightweight, responsive, distraction-free."
    },
    {
      title: "Focus",
      body: "Tools that keep you in the zone."
    }
  ],
  builtInPublicNote: "We're building in public—follow along and help shape Capella Pro."
};
