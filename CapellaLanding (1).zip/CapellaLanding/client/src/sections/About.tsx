import { Section } from "@/components/Section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { about } from "@/content/copy";

export function About() {
  return (
    <Section id="about" title={about.title}>
      <div className="space-y-12">
        <div className="max-w-3xl mx-auto text-center">
          <p className="text-lg text-foreground leading-relaxed" data-testid="text-about-mission">
            {about.body}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {about.values.map((value, index) => (
            <Card
              key={index}
              className="border-border text-center"
              data-testid={`card-value-${index + 1}`}
            >
              <CardHeader>
                <CardTitle className="text-lg" data-testid={`text-value-title-${index + 1}`}>
                  {value.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground" data-testid={`text-value-body-${index + 1}`}>
                  {value.body}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="max-w-2xl mx-auto text-center pt-8">
          <p className="text-sm text-muted-foreground italic" data-testid="text-built-in-public">
            {about.builtInPublicNote}
          </p>
        </div>
      </div>
    </Section>
  );
}
